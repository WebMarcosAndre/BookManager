import { Book } from "./Book";

export interface BookParent{
    books:Book[]
}